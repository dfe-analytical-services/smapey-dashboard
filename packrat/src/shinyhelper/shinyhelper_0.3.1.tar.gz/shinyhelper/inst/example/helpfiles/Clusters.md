## Number of Clusters

***
This slider lets you set the number of clusters used in the `kmeans` algorithm. Change the number to see the effect on the graph to the right. 

***
**Warning! This feature is experimental!** This is why it has an exclamation icon, rather than a question. You can use this package for any kind of information in markdown files.
